const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// Set up body-parser middleware to handle URL encoded and JSON data
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Set up Handlebars as the view engine
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server/views'));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/travlrGetaways', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err);
});

// Set up routes
const indexRoutes = require('./app_server/routes/index');
app.use('/', indexRoutes);

// Serve static files (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Error handling for undefined routes (404 error)
app.use((req, res, next) => {
  res.status(404).render('error', { message: 'Page not found' });
});

// Start the server on port 3000
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});